import cv2
import json
import threading
import time
import os
import uuid
from flask import Flask, Response, render_template, request, redirect, url_for, session, jsonify
from read import get_statistical_data
from ultralytics import YOLO



app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # 用于session加密，生产环境请使用更复杂的密钥

# 用户名和密码，您可以从数据库获取实际数据
USER_CREDENTIALS = {
    'admin': 'admin',  # 示例用户名和密码
}

# 加载 YOLOv8 模型
model = YOLO("best.pt")  # 替换为你的模型路径

# 全局变量
processing = False
current_frame = None
frame_lock = threading.Lock()


# 用于更新威胁类别计数的函数
def update_statistical_table(category_index):
    # 读取当前统计数据
    if os.path.exists("statistical_table.txt"):
        with open("statistical_table.txt", "r") as file:
            table = json.load(file)
    else:
        table = [0] * 10  # 假设有10个类别，初始时都是0

    # 增加相应类别的计数
    if 0 <= category_index < len(table):
        table[category_index] += 1
    else:
        print(f"Invalid category index: {category_index}")
        return

    # 将更新后的数据写回文件
    with open("statistical_table.txt", "w") as file:
        json.dump(table, file)


# 处理视频流并检测目标
def process_video(video_path):
    global processing, current_frame

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print("Error: Could not open video.")
        return

    frame_counter = 0  # 用于跟踪已经处理的帧数

    try:
        while cap.isOpened() and processing:
            ret, frame = cap.read()
            if not ret:
                break

            # YOLO 目标检测
            results = model(frame)
            annotated_frame = results[0].plot()  # 绘制检测框

            # 处理检测结果
            for result in results[0].boxes.data:
                class_id = int(result[-1])  # 获取类别ID
                confidence = result[-2]  # 获取置信度

                # 如果置信度高于某个阈值（比如0.5），我们就认为检测到了威胁
                if confidence > 0.5:
                    if frame_counter % 50 == 0:  # 每50帧更新一次统计表
                        update_statistical_table(class_id)  # 更新相应类别的统计

            # 转换为 JPEG 格式
            _, buffer = cv2.imencode('.jpg', annotated_frame)
            frame_bytes = buffer.tobytes()

            # 更新当前帧（线程安全）
            with frame_lock:
                current_frame = frame_bytes

            frame_counter += 1  # 增加帧计数器

            # 控制帧率（模拟实时）
            time.sleep(1 / 30)  # 约 30 FPS

    except Exception as e:
        print(f"Error processing video: {e}")
    finally:
        cap.release()
        processing = False


@app.route('/get_statistical_data', methods=['GET'])
def get_statistical_data_route():
    data = get_statistical_data()  # 调用 read.py 中的函数
    return jsonify(data)


@app.route('/')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))  # 如果用户未登录，重定向到登录页面
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username in USER_CREDENTIALS and USER_CREDENTIALS[username] == password:
            session['username'] = username
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error="Invalid credentials. Please try again.")

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('username', None)  # 移除 session 中的用户名
    return redirect(url_for('login'))  # 重定向到登录页面


@app.route('/upload', methods=['POST'])
def upload_video():
    if 'username' not in session:
        return {"error": "Unauthorized"}, 401  # 未登录用户返回 401

    global processing

    if 'video' not in request.files:
        return {"error": "No video file"}, 400  # 如果没有上传视频文件，返回错误

    file = request.files['video']
    if file.filename == '':
        return {"error": "No file selected"}, 400  # 如果文件名为空，返回错误

    # 保存临时文件
    temp_path = f"processed\\temp_{uuid.uuid4()}.mp4"
    file.save(temp_path)

    # 启动处理线程
    processing = True
    threading.Thread(target=process_video, args=(temp_path,)).start()

    return {"status": "Processing started"}


@app.route('/video_feed')
def video_feed():
    if 'username' not in session:
        return Response("Unauthorized", status=401)  # 未登录返回 401

    def generate():
        global current_frame
        while processing:
            with frame_lock:
                if current_frame:
                    yield (b'--frame\r\n'
                           b'Content-Type: image/jpeg\r\n\r\n' + current_frame + b'\r\n')
            time.sleep(0.03)  # 控制推送频率

    return Response(
        generate(),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )


if __name__ == '__main__':
     app.run(host="0.0.0.0", port=5000, threaded=True)


