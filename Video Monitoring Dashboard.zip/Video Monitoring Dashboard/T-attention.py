import warnings

warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('D:\\yolov8\\ultralytics\\cfg\models\\v8\\yolov8_Triplet_Attention.yaml').load("best.pt")
    model.train(data="D:\\yolov8\\T-attention.yaml",
                cache=False,
                imgsz=640,
                epochs=100,
                batch=4,
                close_mosaic=10,
                workers=0,
               # device='GPU',  # 修改为 GPU
                optimizer='SGD',  # 使用 SGD 优化器
                project='runs/train',
                name='exp',
                )
