// login.js
document.querySelector('form').addEventListener('submit', function(event) {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    if (username === "" || password === "") {
        alert("用户名和密码不能为空");
        event.preventDefault(); // 阻止表单提交
    }
});
