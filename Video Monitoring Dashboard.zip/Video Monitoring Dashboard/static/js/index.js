let currentFullscreen = null;
let processing = false;

function toggleFullscreen(element) {
    if (element.classList.contains('fullscreen')) {
        element.style.transform = 'translate(-50%, -50%) scale(0)';
        setTimeout(() => {
            element.classList.remove('fullscreen');
            element.style.transform = '';
            currentFullscreen = null;
        }, 500);
    } else {
        if (currentFullscreen) return;

        element.classList.add('fullscreen');
        element.style.transform = 'translate(-50%, -50%) scale(0)';
        setTimeout(() => {
            element.style.transform = 'translate(-50%, -50%) scale(1)';
        }, 10);
        currentFullscreen = element;
    }
}

function exitFullscreen() {
    if (currentFullscreen) {
        toggleFullscreen(currentFullscreen);
    }
}

// 初始化图表
var objectCountChart = echarts.init(document.getElementById('objectCountChart'));
//var objectCountOption = {
//    title: { text: 'Object Detection Count' },
//    xAxis: { type: 'category', data: ['Person', 'Car', 'Truck', 'Bicycle', 'Dog'] },
//    yAxis: { type: 'value' },
//    series: [{ data: [5, 20, 15, 13, 2], type: 'bar' }]
//};
//objectCountChart.setOption(objectCountOption);
fetch('/get_statistical_data')
            .then(response => response.json())
            .then(data => {
                var objectCountOption = {
                    title: { text: 'Object Detection Count' },
                    xAxis: {
                        type: 'category',
                        data: ['Person', 'Car', 'Truck', 'Bicycle', 'Dog', '6', '7', '8', '9', '10']
                    },
                    yAxis: { type: 'value' },
                    series: [{
                        data: data, // 使用从后端获取的文件数据
                        type: 'bar'
                    }]
                };

                // 更新图表
                objectCountChart.setOption(objectCountOption);
            })
            .catch(error => console.error('Error fetching data:', error));

// 初始化地图
var map = L.map('terrainMap').setView([39.9042, 116.4074], 12);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// 视频上传和处理逻辑
document.getElementById('videoInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (!file) return;

    // 显示原始视频
    const originalVideo = document.getElementById('originalVideo');
    originalVideo.src = URL.createObjectURL(file);

    // 清除之前的处理视频
    const processedVideo = document.getElementById('processedVideo');
    processedVideo.src = '';

    // 更新状态
    const statusDiv = document.getElementById('status');
    statusDiv.textContent = "正在处理视频...";
    statusDiv.style.color = "yellow";

    // 上传到后端处理
    const formData = new FormData();
    formData.append('video', file);

    fetch('/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }

        // 开始接收实时视频流
        processedVideo.src = "/video_feed?" + new Date().getTime();
        statusDiv.textContent = "实时处理中...";
        statusDiv.style.color = "lightgreen";

        // 同时准备最终处理后的视频（可选）
        const finalVideo = new Video();
        finalVideo.src = `/processed_video/${data.processed_filename}`;
    })
    .catch(error => {
        console.error('Error:', error);
        statusDiv.textContent = `处理失败: ${error.message}`;
        statusDiv.style.color = "red";
    });
});

function updateWarningLight(detected) {
    var warningLight = document.getElementById('warningLight');
    if (detected) {
        warningLight.style.backgroundColor = 'red';
        warningLight.innerHTML = 'Threat Detected!';
    } else {
        warningLight.style.backgroundColor = 'green';
        warningLight.innerHTML = 'No Threat Detected';
    }
}

// 模拟警告灯变化
//setTimeout(() => updateWarningLight(true), 5000);
//setTimeout(() => updateWarningLight(false), 10000);

// 更新警示灯的状态和内容
function updateWarningLight(threatDetected, categoryName = "") {
    const warningLight = document.getElementById("warningLight");

    if (threatDetected) {
        warningLight.style.backgroundColor = "red";  // 警示灯变红
        warningLight.innerText = `${categoryName} detected`; // 显示威胁类别
    } else {
        warningLight.style.backgroundColor = "green";  // 警示灯恢复正常
        warningLight.innerText = "No Threat Detected"; // 恢复为默认文本
    }
}

// 初始化一个数组，记录每个类别上次的最大威胁数量，初始值为 0
let lastMaxThreatCounts = new Array(10).fill(0);  // 假设有10个类别

// 监听威胁数据的更新
function checkForThreats() {
    fetch('/get_statistical_data')  // 向后端请求统计数据
        .then(response => response.json())
        .then(data => {
            let maxThreatIndex = -1;
            let maxThreatCount = 0;

            // 遍历数据，找出威胁类别
            for (let i = 0; i < data.length; i++) {
                if (data[i] > maxThreatCount) {
                    maxThreatCount = data[i];
                    maxThreatIndex = i;
                }
            }

            // 只有当当前类别的数量大于上次存储的数量时，才认为检测到威胁
            if (maxThreatCount > lastMaxThreatCounts[maxThreatIndex] && maxThreatCount > 0) {
                const threatNames = ["Bicycle", "Boat", "Bottle", "Bus", "Car", "Cat", "Chair", "Cup", "Dog", "Motorbike"];
                updateWarningLight(true, threatNames[maxThreatIndex]);  // 传入类别名称
                lastMaxThreatCounts[maxThreatIndex] = maxThreatCount;  // 更新该类别的数量
            } else {
                updateWarningLight(false);  // 如果没有检测到新的威胁
            }
        })
        .catch(error => console.error("获取威胁数据失败:", error));
}

// 每500毫秒检查一次是否有新的威胁
setInterval(checkForThreats, 2000);



