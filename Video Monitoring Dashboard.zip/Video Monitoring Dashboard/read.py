import json
import os

# 假设统计数据存储在 statistical_table.txt 中
def get_statistical_data():
    if os.path.exists("statistical_table.txt"):
        with open("statistical_table.txt", "r") as file:
            data = json.load(file)  # 假设文件格式是 JSON 数组
        return data
    else:
        return [0] * 10  # 如果文件不存在，返回默认的空数据
